export class Position {
    private _id: string;
    private PositionName: string;
    private PositionDescription: string;
    private PositionBaseSalary: number;
    private __v: number;

    constructor() {

    }
}